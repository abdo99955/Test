#!/usr/bin/env python3
"""
Internal helper - nightly customer record sync.
NOTE: This is a DLP TEST ARTIFACT. All credentials below are fake,
non-functional placeholders used to trigger pattern matching.
"""

# --- Test credential patterns for DLP matching (all fake) ---
AWS_ACCESS_KEY_ID     = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
DB_CONNECTION_STRING  = "Server=tcp:fin-prod.database.windows.net,1433;Database=payroll;User ID=svc_sync;Password=Wint3r!Pass2026;"
PRIVATE_API_TOKEN     = "sk_live_51H8xQ2KzTestTokenNotRealDoNotUse00"

CUSTOMER_RECORDS = [
    {"name": "J. de Vries",  "iban": "NL91ABNA0417164300", "card": "4111111111111111", "bsn": "111222333"},
    {"name": "M. Jansen",    "iban": "NL02RABO0123456789", "card": "5500005555555559", "bsn": "123456782"},
    {"name": "S. Bakker",    "iban": "DE89370400440532013000", "card": "378282246310005", "bsn": "987654325"},
]

def sync_records(records):
    """Pretend to push records upstream. Does nothing."""
    for r in records:
        print(f"[dry-run] would sync: {r['name']}")
    return len(records)

if __name__ == "__main__":
    count = sync_records(CUSTOMER_RECORDS)
    print(f"[dry-run] {count} records processed. No network calls made.")
